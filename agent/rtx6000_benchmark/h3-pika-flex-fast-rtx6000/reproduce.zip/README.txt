Reproduction
1. Check out script2video at the repo_commit in source/provenance.json.
2. Apply source/runtime.patch with git apply. Copy harness/*.py into
   agent/rtx6000_benchmark/ and inputs/* into agent/rtx6000_benchmark/inputs/.
3. Use the recorded Python/Torch/CUDA/package versions and existing H3 model
   weights under cache/minimax_h3. Model provenance is in model_provenance.json;
   inputs, workflow graphs, exact commands and seeds are in the run records.
4. Build SageAttention/sageattention3_blackwell at the recorded SageAttention
   commit, with csrc/cutlass at the recorded CUTLASS commit. Build with
   CUDA_HOME=/usr/local/cuda-13.1 and MAX_JOBS=8; use pip/uv --no-deps
   --no-build-isolation --target a private site-packages overlay.
5. Set PYTHONPATH to that overlay. Use the benchmark interpreter explicitly.
   On an idle dedicated GPU, run:
   python -m agent.rtx6000_benchmark.stage_pipeline --name followup_cal_20 --chunks 20 --calibrate-only --run
   python -m agent.rtx6000_benchmark.run_fast_comparison
   python -m agent.rtx6000_benchmark.report_fast_comparison
The comparison runner preserves existing completed runs. Use fresh run names
or a fresh benchmark directory for a new measurement. Calibration is not timed
as part of full-video latency. Do not run quality evaluation during generation.
The deployed worker is not changed by this benchmark. No model weights bundled.
